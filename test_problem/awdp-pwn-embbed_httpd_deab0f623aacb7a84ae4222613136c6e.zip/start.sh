#!/bin/sh
while true
do
    echo "httpd starting...."
    timeout 30s /home/ctf/qemu-mipsel-static -L /home/ctf/lib  ./pwn -b/home/ctf/html/ -p9999
done

sleep infinity;

